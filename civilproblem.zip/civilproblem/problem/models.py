from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Status(models.Model):
    name = models.CharField(max_length=20, null=True)
    def __str__(self):
        return self.name
class Profile(models.Model):
    status = models.ForeignKey(Status, on_delete=models.CASCADE, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    city = models.CharField(max_length=30, null=True)
    address = models.CharField(max_length=50, null=True)
    contact = models.CharField(max_length=10, null=True)

    def __str__(self):
        return self.user.username
class Send_Feedback(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE, null=True)
    message1 = models.TextField(null=True)
    date = models.CharField(max_length=30, null=True)

    def __str__(self):
        return self.profile.user.username
class Working_Status(models.Model):
    name = models.CharField(max_length=20, null=True)

    def __str__(self):
        return self.name
class Add_Problem(models.Model):
    status=models.ForeignKey(Working_Status, on_delete=models.CASCADE, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    title=models.CharField(max_length=70,null=True)
    des=models.CharField(max_length=70,null=True)
    loc=models.CharField(max_length=70,null=True)
    post_date=models.CharField(max_length=70,null=True)
    start_date=models.CharField(max_length=70,null=True)
    estimate_com_date=models.CharField(max_length=70,null=True)
    com_date=models.CharField(max_length=70,null=True)
    voter = models.TextField(null=True)
    vote = models.IntegerField(null=True)
    def __str__(self):
        return self.title+" "+str(self.vote)
class Contact(models.Model):
    sub = models.CharField(max_length=30, null=True)
    con = models.CharField(max_length=10, null=True)
    fname = models.CharField(max_length=10, null=True)
    lname = models.CharField(max_length=10, null=True)
    email = models.EmailField(max_length=10, null=True)

    def __str__(self):
        return self.fname
