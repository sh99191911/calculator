from django.shortcuts import render,redirect
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from datetime import date
# Create your views here.
def Home(request):
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'index.html',d)

def User_Home(request):
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'user_index.html',d)

def About(request):
    return render(request, 'about.html')



def Logout(request):
    if not request.user.is_authenticated:
        return redirect('login')
    logout(request)
    return redirect('home')
def Login(request):
    error = ""
    if request.method == 'POST':
        u = request.POST['aadhar']
        p = request.POST['psw']
        user1 = authenticate(username=u, password=p)
        data = ""
        try:
            data = Profile.objects.get(user=user1)
        except:
            pass
        if user1:
            if data.status.name =="accepted":
                if not user1.is_staff:
                    login(request, user1)
                    error = "yes"
            else:
                error = "pending"
        else:
            error = "notregister"
    d = {'error': error}
    return render(request, 'login.html', d)
def Login_Admin(request):
    error = False
    if request.method == 'POST':
        u = request.POST['uname']
        p = request.POST['psw']
        user = authenticate(username=u, password=p)
        if user.is_staff:
            login(request, user)
            return redirect('admin_base')
        else:
            error = True
    d = {'error': error}
    return render(request, 'login_admin.html', d)
def Admin_Base(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    book=Add_Problem.objects.all()
    b=0
    for i in book:
        b+=1
    b1=0
    b2=0
    for i in book:
        if i.status.name=='In Progress':
            b1+=1
        if i.status.name=='Problem Solved':
            b2+=1

    d={'b':b,'b1':b1,'b2':b2}
    return render(request, 'admin_home.html',d)

def Add_problem(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cat = User.objects.all()
    error=False
    date1 = date.today()
    if request.method=="POST":
        t = request.POST['title']
        des = request.POST['des']
        loc = request.POST['loc']
        ct = User.objects.filter(username=request.user.username).first()
        status = Working_Status.objects.get(name='Not Started')
        Add_Problem.objects.create(title=t, des=des, vote=0, voter="", loc=loc, post_date=date.today(), status=status,start_date='null', com_date='null', estimate_com_date='null', user=ct)
        error = True
    d = {'cat': cat,'error':error,'date1':date1}
    return render(request, 'add_problem.html', d)

def Admin_Add_problem(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cat = User.objects.all()
    error=False
    date1 = date.today()
    if request.method=="POST":
        t = request.POST['title']
        des = request.POST['des']
        loc = request.POST['loc']
        start = request.POST['start_date']
        est = request.POST['estimated_date']
        status = Working_Status.objects.get(name='In Progress')
        Add_Problem.objects.create(title=t, des=des, vote=0, voter="", loc=loc, post_date=date.today(), status=status,start_date=start, com_date='null', estimate_com_date=est, user=request.user)
        error=True
    d = {'cat': cat,'error':error,'date1':date1}
    return render(request, 'admin_addproblem.html', d)

def Logout_Admin(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    logout(request)
    return redirect('home')


def admin_notstarted(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'admin_notstarted.html', d)


def Edit_admin_notstarted(request,pid):
    if not request.user.is_staff:
        return redirect('login_admin')
    book = Add_Problem.objects.get(id=pid)
    stat = Working_Status.objects.all()
    if request.method == "POST":
        n = request.POST['title']
        s = request.POST['estimate_com_date']
        sta = Working_Status.objects.filter(name='In Progress').first()
        book.status = sta
        book.start_date=date.today()
        book.estimate_com_date=s
        book.save()
        return redirect('admin_notstarted')
    d = {'book': book, 'stat': stat}
    return render(request, 'edit_admin_notstarted.html', d)


def admin_inprogress(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'admin_inprogress.html', d)
def user_inprogress(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'user_inprogress.html', d)
def Edit_admin_inprogress(request,pid):
    if not request.user.is_staff:
        return redirect('login_admin')
    book = Add_Problem.objects.get(id=pid)
    stat = Working_Status.objects.all()
    if request.method == "POST":
        n = request.POST['title']
        s = request.POST['com_date']
        sta = Working_Status.objects.filter(name='Problem Solved').first()
        book.start_date=date.today()
        book.status = sta
        book.com_date=s
        book.save()
        return redirect('admin_inprogress')
    d = {'book': book, 'stat': stat}
    return render(request, 'edit_admin_inprogress.html', d)
def admin_completed(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Add_Problem.objects.all()

    d = {'cus': cust}
    return render(request, 'admin_completed.html', d)
def user_completed(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'user_completed.html', d)
def user_allproblem(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'user_allproblem.html', d)

def View_Problem(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'admin_view_problem.html', d)
def user_notstarted(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cust = Add_Problem.objects.all()
    d = {'cus': cust}
    return render(request, 'user_notstarted.html', d)
def View_Customer(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Profile.objects.all()
    d = {'cus': cust}
    return render(request, 'view_customer.html', d)
def View_User(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    cust = Profile.objects.all()
    d = {'cus': cust}
    return render(request, 'view_user.html', d)
def Delete_Customer(request, pid):
    if not request.user.is_staff:
        return redirect('login_admin')
    if Profile.objects.filter(id=pid).exists():
        pro = Profile.objects.get(id=pid)
        pro.delete()
        message1 = messages.info(request, 'User Deleted')
        return redirect('view_user')
def Edit_Profile(request, pid):
    data = Profile.objects.get(id=pid)
    error=False
    if request.method == 'POST':
        n = request.POST['name']
        u = request.POST['uname']
        c = request.POST['city']
        ad = request.POST['add']
        e = request.POST['email']
        con = request.POST['contact']
        user = User.objects.get(username=u)
        user.first_name = n
        user.email = e
        user.save()
        data.user = user
        data.contact = con
        data.address = ad
        data.city = c
        data.save()
        error=True
    d = {'data': data,'error':error}
    return render(request, 'edit_profile.html', d)
def View_profile(request):
    if not request.user.is_authenticated:
        return redirect('login')
    data1 = User.objects.get(id=request.user.id)
    data = Profile.objects.filter(user=data1).first()
    d = {'data': data}
    return render(request, 'view_profile.html', d)
def View_contact(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    data = Contact.objects.all()
    d = {'data': data}
    return render(request, 'view_contact.html', d)

def Feedback(request, pid):
    if not request.user.is_authenticated:
        return redirect('login')
    date1 = date.today()
    user = User.objects.get(id=pid)
    pro = Profile.objects.filter(user=user).first()
    error=False
    if request.method == "POST":
        m = request.POST['message']
        pro = Profile.objects.filter(user=user).first()
        Send_Feedback.objects.create(profile=pro, date=date1, message1=m)
        error=True
    d = {'pro': pro, 'date1': date1,'error':error}
    return render(request, 'feedback.html', d)
def View_feedback(request):
    if not request.user.is_staff:
        return redirect('login_admin')
    feed = Send_Feedback.objects.all()
    d = {'feed': feed}
    return render(request, 'view_feedback.html', d)
def Delete_feedback(request, pid):
    if not request.user.is_staff:
        return redirect('login_admin')
    if Send_Feedback.objects.filter(id=pid).exists():
        pro = Send_Feedback.objects.get(id=pid)
        pro.delete()
        message1 = messages.info(request, 'Selected Feedback Deleted')
        return redirect('view_feedback')
def Edit_status(request,pid):
    if not request.user.is_staff:
        return redirect('login_admin')
    error=False
    book = Profile.objects.get(id=pid)
    stat = Status.objects.all()
    if request.method == "POST":
        n = request.POST['aadhar']
        s = request.POST['st']
        user = User.objects.get(username=n)
        book.user = user
        sta = Status.objects.filter(name=s).first()
        book.status = sta
        book.save()
        error=True
    d = {'book': book, 'stat': stat,'error':error}
    return render(request, 'status.html', d)
def change_password(request):
     if not request.user.is_authenticated:
        return redirect('login')
     error=""
     data = User.objects.get(username=request.user.username)
     if request.method=="POST":
        o=request.POST['password1']
        n=request.POST['password2']
        if o==n:
            data.set_password(o)
            data.save()
            login(request,data)
            error="yes"
            return redirect('login')
        else:
            error="not"
     d={'error':error}
     return render(request,'change_password.html',d)

def Add_Profile(request):
    error = False
    if request.method == 'POST':
        n = request.POST['name']
        p = request.POST['pwd']
        c = request.POST['city']
        ad = request.POST['add']
        e = request.POST['email']
        con = request.POST['contact']
        u=request.POST['uname']
        user1 = User.objects.filter(username = u)
        if user1:
            error = True
        else:
            status=Status.objects.get(name='pending')
            user = User.objects.create_user(username=u, email=e, password=p, first_name=n)
            Profile.objects.create(user=user, city=c, address=ad, contact=con,status=status)
            return redirect('login')
    d = {'error':error}
    return render(request, 'profile.html',d)
def Add_Contact(request):
    error = False
    if request.method == 'POST':
        n = request.POST['name']
        p = request.POST['lname']
        e = request.POST['email']
        con1 = request.POST['contact']
        s=request.POST['sub']
        Contact.objects.create(fname=n,lname=p,email=e, con=con1,sub=s)
        error=True
    d = {'error':error}
    return render(request, 'contact.html',d)
def view_desc(request,pid):
    data=Add_Problem.objects.get(id=pid)
    d={'data':data}
    return render(request,'view_des.html',d)
def voting(request,pid,uid):
    user = User.objects.get(id=pid)
    problem = Add_Problem.objects.get(id=uid)
    if not user.username in problem.voter:
        problem.vote+=1
        problem.voter=problem.voter+","+user.username
        problem.save()
    return redirect('user_notstarted')
