from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Profile)
admin.site.register(Send_Feedback)
admin.site.register(Status)
admin.site.register(Working_Status)
admin.site.register(Add_Problem)
admin.site.register(Contact)
