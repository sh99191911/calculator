"""onlinebookshop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from problem.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',Home,name='home'),
    path('about/',About,name='about'),
    path('User_Home/',User_Home,name='User_Home'),
    path('send_feedback/(?P<pid>[0-9]+)', Feedback, name='send_feedback'),
    path('delete_feedback/(?P<pid>[0-9]+)', Delete_feedback, name='delete_feedback'),
    path('contact/',Contact,name='contact'),
    path('login/',Login,name='login'),
    path('profile', Add_Profile, name='profile'),
    path('contact', Add_Contact, name='contact'),
    path('problem', Add_problem, name='add_problem'),
    path('admin_addproblem', Admin_Add_problem, name='admin_addproblem'),
    path('login_admin', Login_Admin, name='login_admin'),
    path('admin_base', Admin_Base, name='admin_base'),
    path('view_feedback', View_feedback, name='view_feedback'),
    path('view_customer', View_Customer, name='view_customer'),
    path('view_problem', View_Problem, name='admin_view_problem'),
    path('view_user', View_User, name='view_user'),
    path('logout_admin', Logout_Admin, name='logout_admin'),
    path('logout/',Logout,name='logout'),
    path('change_password/',change_password,name='change_password'),
    path('delete_customer/(?P<pid>[0-9]+)',Delete_Customer, name='delete_customer'),
    path('feedback/(?P<pid>[0-9]+)',Feedback, name='feedback'),
    path('view_des/(?P<pid>[0-9]+)',view_desc, name='view_des'),
    path('view_profile',View_profile, name='view_prifile'),
    path('view_contact',View_contact, name='view_contact'),
    path('voting/(?P<pid>[0-9]+)/(?P<uid>[0-9]+)',voting, name='voting'),
    path('edit_profile/(?P<pid>[0-9]+)', Edit_Profile, name='edit_profile'),
    path('admin_notstarted',admin_notstarted, name='admin_notstarted'),
    path('user_notstarted',user_notstarted, name='user_notstarted'),
    path('admin_completed',admin_completed, name='admin_completed'),
    path('user_completed',user_completed, name='user_completed'),
    path('user_allproblem',user_allproblem, name='user_allproblem'),
    path('admin_inprogress',admin_inprogress, name='admin_inprogress'),
    path('user_inprogress',user_inprogress, name='user_inprogress'),
    path('status/(?P<pid>[0-9]+)', Edit_status, name='status'),
    path('edit_notstarted/(?P<pid>[0-9]+)', Edit_admin_notstarted, name='edit_admin_notstarted'),
    path('edit_inprogress/(?P<pid>[0-9]+)', Edit_admin_inprogress, name='edit_admin_inprogress'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
